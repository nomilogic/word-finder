export const wordsL24 = [
  "diphenylaminechlorarsine",
  "disestablishmentarianism",
  "electrocardiographically",
  "formaldehydesulphoxylate",
  "magnetothermoelectricity",
  "microelectrophoretically",
  "pathologicopsychological",
  "preobtrudingpreobtrusion",
  "pseudointernationalistic",
  "scientificophilosophical",
  "tetraiodophenolphthalein",
  "thyroparathyroidectomize"
];
