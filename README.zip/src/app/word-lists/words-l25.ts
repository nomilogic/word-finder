export const wordsL25 = [
  "antidisestablishmentarian",
  "demethylchlortetracycline",
  "electroencephalographical",
  "immunoelectrophoretically",
  "microspectrophotometrical",
  "philosophicopsychological",
  "regeneratoryregeneratress",
  "superincomprehensibleness"
];
