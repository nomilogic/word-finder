export const wordsL27 = [
  "electroencephalographically",
  "hydroxydesoxycorticosterone",
  "microspectrophotometrically"
];
