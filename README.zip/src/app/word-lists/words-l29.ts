export const wordsL29 = [
  "cyclotrimethylenetrinitramine",
  "trinitrophenylmethylnitramine"
];
