export const wordsL31 = [
  "dichlorodiphenyltrichloroethane"
];
