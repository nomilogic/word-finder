export const wordsL28 = [
  "antidisestablishmentarianism",
  "hydroxydehydrocorticosterone"
];
